const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const path = require('path');

const app = express();
const PORT = 5000;

app.use('/rpc', createProxyMiddleware({
  target: 'http://127.0.0.1:8545',
  changeOrigin: true,
  pathRewrite: {
    '^/rpc': '',
  },
}));

app.use(express.static('frontend'));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Frontend: http://0.0.0.0:${PORT}`);
  console.log(`RPC Proxy: http://0.0.0.0:${PORT}/rpc`);
});
