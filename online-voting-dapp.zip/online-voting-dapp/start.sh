#!/usr/bin/env bash
# start.sh - start Hardhat node, deploy, and serve frontend

# 1) start hardhat node in background on localhost
npx hardhat node --hostname 127.0.0.1 --port 8545 &

# Let node boot
sleep 3

# 2) deploy contract to the node
npx hardhat run scripts/deploy.js --network localhost

# 3) start the proxy server on port 5000
node server.js
