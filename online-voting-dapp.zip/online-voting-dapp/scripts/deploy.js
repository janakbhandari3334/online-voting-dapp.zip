async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying with:", deployer.address);
  const Voting = await ethers.getContractFactory("VotingSystem");
  const names = ["Alice", "Bob", "Charlie"];
  const voting = await Voting.deploy(names);
  await voting.waitForDeployment();
  const address = await voting.getAddress();
  console.log("Voting deployed at:", address);

  // save address + abi to frontend folder
  const fs = require('fs');
  const artifactsPath = "artifacts/contracts/VotingSystem.sol/VotingSystem.json";
  const abi = JSON.parse(fs.readFileSync(artifactsPath)).abi;
  const json = { address: address, abi: abi };
  if (!fs.existsSync("frontend")) fs.mkdirSync("frontend");
  fs.writeFileSync("frontend/contract.json", JSON.stringify(json, null, 2));
  console.log("Saved frontend/contract.json");
}
main().catch(e => { console.error(e); process.exit(1); });